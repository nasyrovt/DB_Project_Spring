package com.example.accessingdatajpa;

public class Abonne {
    private Long abonneeId;
    private String name;
    private String surName;
    private String dateDeNaissance;
    private String adresse;
    private AllEnums.Sexe sexe;
    private float prime;

}
